# backend/api/__init__.py
# empty on purpose (namespace package)
