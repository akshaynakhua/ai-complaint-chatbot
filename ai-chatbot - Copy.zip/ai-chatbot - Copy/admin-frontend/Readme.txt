1.Start backend (PowerShell):

$env:ADMIN_USER="admin"
$env:ADMIN_PASS="admin"
$env:ADMIN_ORIGIN="http://localhost:5174"
python backend/admin_app.py


2.Serve the admin frontend:

cd admin-frontend
python -m http.server 5174

3.Open: http://localhost:5174/login.html